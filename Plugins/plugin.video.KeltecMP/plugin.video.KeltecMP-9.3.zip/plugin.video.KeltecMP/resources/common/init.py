[
    {
        "name": "[B][COLOR white]KelTec[/COLOR] [COLOR crimson]Play TV[/COLOR][/B][COLOR orange] | [/COLOR]Tv ao Vivo",
        "url": "https://urlredir.ml/%F0%9D%93%B5%F0%9D%93%B2%F0%9D%93%BC%F0%9D%93%BD%F0%9D%93%AA-1",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "3ad99ef9-eb57-4e87-ab18-dbbb9b9ffa7b"
    },
    {
        "name": "[B][COLOR white]KelTec[/COLOR] [COLOR crimson]Play TV[/COLOR][/B][COLOR orange] | [/COLOR]Filmes 1",
        "url": "https://urlredir.ml/%F0%9D%93%B5%F0%9D%93%B2%F0%9D%93%BC%F0%9D%93%BD%F0%9D%93%AA-2",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a56a8001-e0e2-4b7b-89af-42d8b7b539be"
    },
    {
        "name": "[B][COLOR white]KelTec[/COLOR] [COLOR crimson]Play TV[/COLOR][/B][COLOR orange] | [/COLOR]Filmes 2",
        "url": "https://urlredir.ml/%F0%9D%93%B5%F0%9D%93%B2%F0%9D%93%BC%F0%9D%93%BD%F0%9D%93%AA-3",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "4f03df0c-ab79-4bf3-8860-a4a7a22e1a1b"
    },
    {
        "name": "[B][COLOR white]KelTec[/COLOR] [COLOR crimson]Play TV[/COLOR][/B][COLOR orange] | [/COLOR]Novelas",
        "url": "https://urlredir.ml/%F0%9D%97%B9%F0%9D%97%B6%F0%9D%98%80%F0%9D%98%81%F0%9D%97%AE-%F0%9D%9F%B0",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "f553a446-b2a8-4067-a20b-bd45361da911"
    },
    {
        "name": "[B][COLOR white]KelTec[/COLOR] [COLOR crimson]Play TV[/COLOR][/B][COLOR orange] | [/COLOR]Series",
        "url": "https://urlredir.ml/%CA%9F%C9%AAs%E1%B4%9B%E1%B4%80-5",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "a27c43b8-d708-4ee0-94a5-5be84be504cd"
    }
]