[
    {
        "name": "[B][COLOR white]KelTec[/COLOR] [COLOR crimson]Play TV[/COLOR][/B][COLOR orange] | [/COLOR]Tv ao Vivo",
        "url": "https://urlredir.ml/%F0%9D%93%B5%F0%9D%93%B2%F0%9D%93%BC%F0%9D%93%BD%F0%9D%93%AA-1",
        "image": "",
        "logos": "",
        "cache": 0,
        "uuid": "3ad99ef9-eb57-4e87-ab18-dbbb9b9ffa7b"
    }
]