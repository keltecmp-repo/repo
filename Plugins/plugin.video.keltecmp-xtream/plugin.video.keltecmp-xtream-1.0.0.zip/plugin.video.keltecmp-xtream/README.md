# plugin.video.xtreamtotal
plugin.video.xtreamtotal kodi addon

Para usar addon é necessario inserir credenciais do xcui

não vendemos iptv, isso é apenas um addon que acessa api do xcui mas é necessario dados como host, username e password que pode ser adquirido com alguem ou em grupos no telegram

## Recursos do addon

menus: Informações, Pesquisa, Tv Ao vivo, Filmes, Séries e Configurações

suporta epg (guia de programação)

sistema anti-bloqueio (Proxy, DNS)

## repo para instalar

coloque no gestor de arquivo: https://oneplayhd.com/oneplay

vá em addons e em instalar de um arquivo zip, habilite fontes desconhecidas e volte denovo em instalar de um arquivo zip

selecione oneplay e instale o repositorio

vá em instalar via repositorio e em Oneplay repositorio vá em addons de video e instale Xtream Total

## Como usar de forma gratuita?

o Addon sozinho não faz nada, ele depende de credenciais de xcui (xtream codes), para poder testar pesquise grupos de iptv no telegram e pegue as credenciais.

